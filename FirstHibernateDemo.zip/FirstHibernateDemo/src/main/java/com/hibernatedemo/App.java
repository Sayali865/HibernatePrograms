package com.hibernatedemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    
       Configuration cfg = new Configuration();
       cfg.configure("hibernate.cfg.xml");
       
       // session factory created
       SessionFactory sessionFactory=cfg.buildSessionFactory();

       //open the session 
       Session session = sessionFactory.openSession();
       
       //begin transaction
       Transaction tr = session.beginTransaction();
       
      // map object to database
       Employee emp1 = new Employee();
       emp1.setId(3);
       emp1.setName("Payal");
       emp1.setDept("Chemical");
       emp1.setSalary(40000);
       
       Department dp = new Department();
       dp.setId(1002);
       dp.setName("CS");
       dp.setLocation("Chinchwad");
       
       session.save(emp1);
       session.save(dp);
       tr.commit();
       session.close();
       System.out.println("Employee add hua");
       System.out.println("Department add hua");
    }
}
